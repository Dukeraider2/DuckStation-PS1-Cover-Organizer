Add-Type -AssemblyName System.Drawing

# Define root path dynamically based on script location
$duckStationRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$sourceDir = Join-Path $duckStationRoot "covers"
$tempDir = Join-Path $duckStationRoot "temp"
$exportDir = Join-Path $duckStationRoot "coverexport"
$logPath = Join-Path $duckStationRoot "debug_log.txt"

# Ensure necessary directories exist
foreach ($dir in @($sourceDir, $tempDir, $exportDir)) {
    if (-not (Test-Path $dir)) {
        New-Item -Path $dir -ItemType Directory | Out-Null
    }
}

# Clear temp directory before running
Get-ChildItem -Path $tempDir -File | Remove-Item -Force -ErrorAction SilentlyContinue

# Loop through each image in the source folder
Get-ChildItem -Path $sourceDir -Filter *.jpg | ForEach-Object {
    $originalName = $_.BaseName -replace "-", ""
    $sanitizedName = "$originalName.jpg"
    $img = [System.Drawing.Image]::FromFile($_.FullName)

    # Calculate new size while preserving aspect ratio
    $width = 512
    $height = 512
    $ratioX = $width / $img.Width
    $ratioY = $height / $img.Height
    $ratio = [math]::Min($ratioX, $ratioY)
    $newWidth = [math]::Round($img.Width * $ratio)
    $newHeight = [math]::Round($img.Height * $ratio)
    $xOffset = [math]::Round(($width - $newWidth) / 2)
    $yOffset = [math]::Round(($height - $newHeight) / 2)

    $newImg = New-Object System.Drawing.Bitmap $width, $height
    $graphics = [System.Drawing.Graphics]::FromImage($newImg)
    $graphics.Clear([System.Drawing.Color]::Black)
    $graphics.DrawImage($img, $xOffset, $yOffset, $newWidth, $newHeight)

    # Save the resized image with new name
    $destPath = Join-Path $tempDir $sanitizedName
    $newImg.Save($destPath, [System.Drawing.Imaging.ImageFormat]::Jpeg)

    # Clean up
    $graphics.Dispose()
    $newImg.Dispose()
    $img.Dispose()

    Add-Content -Path $logPath -Value "[SUCCESS] $sanitizedName resized at $(Get-Date)"
}

# === Call organization script ===
Start-Process -FilePath (Join-Path $duckStationRoot "organize_resized.bat")
Write-Host "Resizing complete and organization started."
