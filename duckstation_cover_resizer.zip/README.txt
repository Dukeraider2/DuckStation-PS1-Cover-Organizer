# DuckStation PS1 Cover Organizer Add-on

## 📌 Purpose
This script set is designed to convert DuckStation-downloaded PS1 cover art into a PS3-compatible format. It ensures that cover images are:
- Resized to 512x512 pixels (with optional black padding for aspect-ratio preservation)
- Placed in appropriately named folders for easier indexing by modded PS3 units
- Future versions may include automatic AI upscaling to 1024x1024 for enhanced visual clarity.

## 🧰 Files Included
- `launch_resize.bat`: Launches the resizing process and organizes the results.
- `resize_all_covers.ps1`: Powershell script to resize images with aspect ratio preservation.
- `organize_resized.bat`: Copies resized covers into individual folders named after their filenames.
- `README.md`: You're reading it.

## 📥 Step 1: Enable DuckStation’s Built-in Cover Downloader
According to the [xlenore/psx-covers GitHub page](https://github.com/xlenore/psx-covers), DuckStation includes a built-in downloader:

1. Open DuckStation
2. Go to `Tools` → `Cover Downloader`
3. Paste one of the following URLs:
   - **Flat Covers:**
     ```
     https://raw.githubusercontent.com/xlenore/psx-covers/main/covers/default/${serial}.jpg
     ```
   - **3D Covers:**
     ```
     https://raw.githubusercontent.com/xlenore/psx-covers/main/covers/3d/${serial}.png
     ```
4. Enable **Use Serial File Names**
5. Click `Start` to begin downloading

## 🛠️ Step 2: Installation Instructions
1. Extract the script package to your DuckStation root directory or any subfolder
2. Run `launch_resize.bat`
3. Covers will be resized and organized in the `coverexport` directory

## 📂 Folder Structure
```
DuckStation\
├── covers\                ← DuckStation downloaded covers
├── temp\                  ← Temporary resized cover images
├── coverexport\           ← Final organized folders per cover
├── launch_resize.bat
├── resize_all_covers.ps1
├── organize_resized.bat
└── README.md
```

## 🙏 Acknowledgements
- 🧠 **DuckStation Team** — for their excellent PS1 emulator with native cover downloading support.
- 🖼️ **[xlenore](https://github.com/xlenore)** — for maintaining the `psx-covers` GitHub repository which provides high-quality cover art.

---
Questions or improvements? Feel free to fork or contribute.

— G.W. Griffin
